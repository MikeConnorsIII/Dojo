import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h2>Things I need to do</h2>
      <h3>Learn React</h3>
      <h3>Climb Mt. Everest</h3>
      <h3>Run a marathon</h3>
      <h3>Feed the dogs</h3>
    </div>
  );
}

export default App;
