import React from 'react'

const Error = () => {
  return (
    <div>
        <img src="https://m.media-amazon.com/images/M/MV5BOTAxOTlmOTAtMjA0Yy00YjVjLWE3OTQtYjAzMWMxOTAwZTY1XkEyXkFqcGdeQXVyMTM1MTE1NDMx._V1_.jpg" alt="OBI WAN" />
        <h1>"These aren't the droids you're looking for!"</h1>

    </div>
  )
}

export default Error