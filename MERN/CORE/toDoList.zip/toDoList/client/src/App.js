import './App.css';
// import ToDoList from "./components/ToDoList";

import ToDoList from './components/ToDoList';

function App(){
  return (
  <ToDoList></ToDoList>
  )
}
export default App;
