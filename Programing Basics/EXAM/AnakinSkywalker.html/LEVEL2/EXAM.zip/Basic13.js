// 1. 
// function print1to255(){
// for (i=1; i<=255; i++){
//     console.log(i);
// }
// }
// print1to255();

// 2. 
// function printOdds1to255(){
// for (i=1; i<=255; i++){
//     if(i % 2 != 0){
//     console.log(i);
//     }
// }
// }
// printOdds1to255();

// 3. 
// function printIntsAndSum0to255(){
// var sum = 0;
// for(i=0; i <= 255; i++){
//     sum = sum + i; 
//     console.log("The current integer is: " + i);  
//     console.log("The sum so far is: " + sum);
// }
// }
// printIntsAndSum0to255();


// 4. 
// var arr = [4,3,2,1,2,3,4,5,4];

// function printArrayVals(arr){
//     for(i=0;i < arr.length; i++)
//     console.log(arr[i]);
// }
// printArrayVals(arr);

// 5. 
// var arr = [4,3,2,1,2,3,4,5,4];

// function printMaxOfArray(arr){
// var max = 0 
// for(i=0; i < arr.length; i++){
//     if(arr[i] > max){
//     max = arr[i];
//     }
// }
// console.log(max);
// }

// printMaxOfArray(arr);

// 6. 
// var arr = [1,2,3,4,5,6,7,8,9];
// function printAverageOfArray(arr){
//     var sum = 0;
//     var Avg = 0;
//     for (i = 0; i < arr.length; i++){
//         sum += arr[i];
//     }
//     Avg = sum / arr.length;
//     console.log(Avg);
// }
// printAverageOfArray(arr);

//7. 
// function ReturnOddsArray1To255(){
//     var oddsArray = [];
//     for(i=1;i<=255;i++){
//         if(i % 2 == 1){
//             oddsArray.push(i);
//         }
//     }
//     return oddsArray;
// }

// console.log(ReturnOddsArray1To255());

// // 8. 
// var arr = [1,2,3,4,5,6,7,8,9];
// function squareArrayVals(arr){
//     for(i=0;i<arr.length;i++){
//         arr[i] = arr[i] * arr[i];
//     }
//     return arr;
// }
// console.log(squareArrayVals(arr));

// // 
// // 9. 
// var arr = [4,-1,2,-3,2,3,-10,5,4];
// function printArrayCountGreaterThanY(arr, y){
//     var count = 0
// for(i=0; i <= arr.length; i++){
//     if(arr[i] > y){
//         count++;
//     }
//     }
//     console.log("The count is " + count);
// }

// printArrayCountGreaterThanY(arr, 4);


// // 10. .

// var arr = [4,-1,2,-3,2,3,-10,5,4];
// function printMaxOfArray(arr){
// // var max = 0;
// for(i=0; i <= arr.length; i++){
//     if(arr[i] < 0){
//     arr[i] = 0
//     }
// }
// console.log(arr);
// }

// printMaxOfArray(arr);

