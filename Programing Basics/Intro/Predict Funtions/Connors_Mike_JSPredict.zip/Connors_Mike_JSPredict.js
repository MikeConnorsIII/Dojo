function myBirthYearFunc(){
        console.log("I was born in " + 1980);
    }
//Console log will state "I was born in 1980"

function myBirthYearFunc(){
        console.log("I was born in " + 1980);
    }
//Console log will state Summing Numbers! 30

function myBirthYearFunc(){
        console.log("I was born in " + 1980);
    }
    // Summing numbers! num1 is 10 num 2 is 20 30