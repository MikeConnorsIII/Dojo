function login(element){
    element.innerText="Logout";
}

function derete(element){
    element.remove();
}

function headsup(){
    alert("Ninja was liked");
}