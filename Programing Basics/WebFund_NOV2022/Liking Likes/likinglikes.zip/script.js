function add1(id){
    document.querySelector(id).innerText++;
}

function add2(lambofgod){
    document.querySelector(lambofgod).innerText++;
}

function add3(id3){
    document.querySelector(id3).innerText++
}