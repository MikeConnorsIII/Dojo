//1 to 20 odds
// for(var i = 0; i <= 20; i++){
//     if(i % 2 == 1){
//         console.log(i);
//     }
// }


//2 all values divisible by 3 from 100 down to 0
// for(var i=100; i >= 0; i--){
//     if(i % 3 ==0){
//         console.log(i);
//     }
// }

//3 Print sequence
// var Arr = [4, 2.5, 1, -0.5, -2, -3.5];

// for(var i = 0; i < Arr.length; i++){
//     console.log(Arr[i]);
// }


//add 1 to 100
// function sum(n){
// var total = 0;
// for(var i = 1; i <=n; i++){
//     console.log(i);
//     total += i;
// }
//     return total;
// }

// console.log(sum(100));

//5 

// function mulki(n){
// var product = 1 
// for(var i = 1; i <= n; i++){
//     product *= i; 
//     console.log(product);
// }
// return product;
// }

// console.log(mulki(12));