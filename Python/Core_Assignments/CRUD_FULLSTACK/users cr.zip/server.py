from flask import Flask, render_template, redirect, request
from user_model import User
# import the class from friend.py

app = Flask(__name__)
app.secret_key = "diuyafghvbgsbd"
@app.route("/users")
def index():
    all_users = User.get_all()
    return render_template("all.html", all_users = all_users)

@app.route('/users/new')
def transfer():
    return render_template("create.html")

@app.route("/users/create", methods = ["POST"])
def create():
    User.create(request.form)
    return redirect('/users')


if __name__ == "__main__":
    app.run(debug=True)